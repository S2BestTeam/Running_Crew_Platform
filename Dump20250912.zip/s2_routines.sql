-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Temporary view structure for view `welcome_view`
--

DROP TABLE IF EXISTS `welcome_view`;
/*!50001 DROP VIEW IF EXISTS `welcome_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `welcome_view` AS SELECT 
 1 AS `crewId`,
 1 AS `crewName`,
 1 AS `crewProfileImg`,
 1 AS `status`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `user_post_view`
--

DROP TABLE IF EXISTS `user_post_view`;
/*!50001 DROP VIEW IF EXISTS `user_post_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `user_post_view` AS SELECT 
 1 AS `src`,
 1 AS `post_id`,
 1 AS `crew_id`,
 1 AS `title`,
 1 AS `content`,
 1 AS `created_at`,
 1 AS `user_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `welcome_view`
--

/*!50001 DROP VIEW IF EXISTS `welcome_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `welcome_view` AS select `wt`.`crew_id` AS `crewId`,`ct`.`crew_name` AS `crewName`,`ct`.`profile_picture` AS `crewProfileImg`,(case when (`mt`.`member_id` is null) then '대기중' else '승인 완료' end) AS `status` from ((`welcome_tb` `wt` join `crew_tb` `ct` on((`wt`.`crew_id` = `ct`.`crew_id`))) left join `member_tb` `mt` on(((`wt`.`crew_id` = `mt`.`crew_id`) and (`wt`.`user_id` = `mt`.`user_id`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `user_post_view`
--

/*!50001 DROP VIEW IF EXISTS `user_post_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `user_post_view` AS select 'crew_free' AS `src`,`cf`.`free_id` AS `post_id`,`cf`.`crew_id` AS `crew_id`,`cf`.`title` AS `title`,`cf`.`content` AS `content`,cast(`cf`.`created_at` as datetime) AS `created_at`,`cf`.`user_id` AS `user_id` from `crew_free_tb` `cf` union all select 'crew_notice' AS `src`,`cn`.`notice_id` AS `post_id`,`cn`.`crew_id` AS `crew_id`,`cn`.`title` AS `title`,`cn`.`content` AS `content`,cast(`cn`.`created_at` as datetime) AS `created_at`,`cn`.`user_id` AS `user_id` from `crew_notice_tb` `cn` union all select 'global_free' AS `src`,`gf`.`free_id` AS `post_id`,NULL AS `crew_id`,`gf`.`title` AS `title`,`gf`.`content` AS `content`,cast(`gf`.`created_at` as datetime) AS `created_at`,`gf`.`user_id` AS `user_id` from `global_free_tb` `gf` union all select 'global_notice' AS `src`,`gn`.`notice_id` AS `post_id`,NULL AS `crew_id`,`gn`.`title` AS `title`,`gn`.`content` AS `content`,cast(`gn`.`created_at` as datetime) AS `created_at`,`gn`.`user_id` AS `user_id` from `global_notice_tb` `gn` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping events for database 's2'
--

--
-- Dumping routines for database 's2'
--
/*!50003 DROP FUNCTION IF EXISTS `convert_url` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`%` FUNCTION `convert_url`(
    serverHost VARCHAR(255),
    prefixPath VARCHAR(255), 
    imgPath VARCHAR(255)
) RETURNS varchar(1024) CHARSET utf8mb4 COLLATE utf8mb4_unicode_ci
    READS SQL DATA
    DETERMINISTIC
BEGIN
    DECLARE result VARCHAR(1024);
    
    -- imgPath가 NULL이거나 빈 문자열인 경우 처리
    IF imgPath IS NULL OR imgPath = '' THEN
        RETURN NULL;
    END IF;
    
    -- imgPath가 http:// 또는 https://로 시작하는 경우 그대로 반환
    IF LEFT(imgPath, 7) = 'http://' OR LEFT(imgPath, 8) = 'https://' THEN
        SET result = imgPath;
    ELSE
        -- 각 파라미터의 슬래시 처리
        -- serverHost 끝의 슬래시 제거
        IF RIGHT(serverHost, 1) = '/' THEN
            SET serverHost = LEFT(serverHost, LENGTH(serverHost) - 1);
        END IF;
        
        -- prefixPath 시작과 끝 슬래시 정규화
        IF LEFT(prefixPath, 1) != '/' THEN
            SET prefixPath = CONCAT('/', prefixPath);
        END IF;
        IF RIGHT(prefixPath, 1) = '/' THEN
            SET prefixPath = LEFT(prefixPath, LENGTH(prefixPath) - 1);
        END IF;
        
        -- imgPath 시작 슬래시 제거 (있다면)
        IF LEFT(imgPath, 1) = '/' THEN
            SET imgPath = SUBSTRING(imgPath, 2);
        END IF;
        
        -- 최종 URL 조합
        SET result = CONCAT(serverHost, prefixPath, '/', imgPath);
    END IF;
    
    RETURN result;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:25:08
