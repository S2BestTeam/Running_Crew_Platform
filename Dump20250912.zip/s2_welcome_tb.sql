-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `welcome_tb`
--

DROP TABLE IF EXISTS `welcome_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `welcome_tb` (
  `welcome_id` int NOT NULL AUTO_INCREMENT,
  `crew_id` int NOT NULL,
  `user_id` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '대기중',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`welcome_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `welcome_tb`
--

LOCK TABLES `welcome_tb` WRITE;
/*!40000 ALTER TABLE `welcome_tb` DISABLE KEYS */;
INSERT INTO `welcome_tb` VALUES (2,26,48,'잘가','승인','2025-08-22 10:43:14'),(3,27,50,'ㅇ앙ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ','승인','2025-08-25 15:26:32'),(4,6,50,'ㅏ머누훌ㄴ;허ㅣㄹㅇㅎ;ㅜㅜㅎ','거절','2025-08-25 15:26:45'),(5,22,48,'하이요','승인','2025-08-25 16:09:27'),(6,22,57,'나야','승인','2025-08-27 10:11:13'),(7,4,57,'안녕','승인','2025-08-27 10:18:07'),(10,34,50,'앙아아ㅏㅇ아','대기중','2025-08-27 23:02:24'),(16,4,58,'ㅇㅇ','승인','2025-08-29 16:57:59'),(18,22,55,'하이','승인','2025-09-02 14:30:37'),(22,35,4,'이모님 진짜 죽는다','승인','2025-09-04 17:15:03'),(24,4,50,'ㅅㅂ','승인','2025-09-04 17:34:23'),(30,5,58,'zxcv','대기중','2025-09-07 19:08:07'),(31,22,54,'안녕하세요','승인','2025-09-08 16:10:22'),(32,6,58,'편하게 작성합니다','대기중','2025-09-10 22:44:43'),(33,22,52,'같이 달리고싶어요!!!','승인','2025-09-11 10:58:52'),(34,22,74,'test','대기중','2025-09-12 09:10:27');
/*!40000 ALTER TABLE `welcome_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:25:07
