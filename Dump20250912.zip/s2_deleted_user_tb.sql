-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `deleted_user_tb`
--

DROP TABLE IF EXISTS `deleted_user_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deleted_user_tb` (
  `deleted_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birth_date` date NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` tinyint NOT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `oauth_type` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_km` double NOT NULL DEFAULT '0',
  `gungu_id` int NOT NULL,
  PRIMARY KEY (`deleted_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deleted_user_tb`
--

LOCK TABLES `deleted_user_tb` WRITE;
/*!40000 ALTER TABLE `deleted_user_tb` DISABLE KEYS */;
INSERT INTO `deleted_user_tb` VALUES (1,48,'짜누','염진우','1996-09-08','wlsdn893@gmail.com','부산 중구 광복로 56-14','01056999701',1,'http://localhost:8080/image/profile/43ff3cd7c2dc4d8282c68b2a83dafe02_스크린샷 2025-08-20 002041.png','103469923207328058315','google','2025-08-26 15:42:18',0,10),(2,48,'짜누','염진우','1996-09-08','wlsdn893@gmail.com','부산 중구 광복로 56-14','01056999701',1,'http://localhost:8080/image/profile/43ff3cd7c2dc4d8282c68b2a83dafe02_스크린샷 2025-08-20 002041.png','103469923207328058315','google','2025-08-26 15:44:14',0,10),(3,48,'짜누','염진우','1996-09-08','wlsdn893@gmail.com','부산 중구 광복로 56-14','01056999701',1,'http://localhost:8080/image/profile/43ff3cd7c2dc4d8282c68b2a83dafe02_스크린샷 2025-08-20 002041.png','103469923207328058315','google','2025-08-26 16:13:16',0,10),(4,48,'짜누','염진우','1996-09-08','wlsdn893@gmail.com','부산 중구 광복로 56-14','01056999701',1,'http://localhost:8080/image/profile/43ff3cd7c2dc4d8282c68b2a83dafe02_스크린샷 2025-08-20 002041.png','103469923207328058315','google','2025-08-26 16:14:07',0,10),(5,56,'찌누야','염진우','1996-09-08','wlsdn893@gmail.com','부산 부산진구 서면문화로 2','010-5699-9701',1,'http://localhost:8080/image/profile/8ae068b3279944a0ba02bc88d0f7b4b2_스크린샷 2025-08-26 144725.png','103469923207328058315','google','2025-08-26 16:41:15',0,5),(6,49,'찌누','염진우','1996-09-08','wlsdn893@kakao.com','부산 해운대구 APEC로 17','01056999701',1,'http://img1.kakaocdn.net/thumb/R110x110.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg','4398803918','kakao','2025-08-26 16:42:54',980,9),(7,50,'우야','염진우','1996-09-08','wlsdn893@naver.com','부산 부산진구 서면로 1','01056999701',1,'http://localhost:8080/image/profile/8525f1bab6af4cb4b5f9a506ba39edb3_sb3.jpg','rgrv-AB9gRlWJf1vYDuYpdnqpyG_-X9qYTKmHRKZ_v0','naver','2025-09-01 13:48:01',0,5),(8,50,'삼촌','염진우','1996-09-08','wlsdn893@naver.com','부산 부산진구 서면로 1','01056999701',1,'http://localhost:8080/image/profile/8525f1bab6af4cb4b5f9a506ba39edb3_sb3.jpg','rgrv-AB9gRlWJf1vYDuYpdnqpyG_-X9qYTKmHRKZ_v0','naver','2025-09-05 15:35:16',0,5),(9,50,'삼촌','염진우','1996-09-08','wlsdn893@naver.com','부산 부산진구 서면로 1','01056999701',1,'http://localhost:8080/image/profile/8525f1bab6af4cb4b5f9a506ba39edb3_sb3.jpg','rgrv-AB9gRlWJf1vYDuYpdnqpyG_-X9qYTKmHRKZ_v0','naver','2025-09-05 15:35:24',0,5);
/*!40000 ALTER TABLE `deleted_user_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:25:05
