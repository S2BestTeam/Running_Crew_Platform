-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `report_tb`
--

DROP TABLE IF EXISTS `report_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_tb` (
  `report_id` int NOT NULL AUTO_INCREMENT,
  `crew_id` int NOT NULL,
  `report_member_id` int NOT NULL,
  `reported_member_id` int NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_tb`
--

LOCK TABLES `report_tb` WRITE;
/*!40000 ALTER TABLE `report_tb` DISABLE KEYS */;
INSERT INTO `report_tb` VALUES (5,0,4,51,'맘에 안듬','2025-08-20 15:25:35'),(6,0,4,51,'신고','2025-08-20 15:34:30'),(7,0,4,51,'ㅋㅌㅍㅊ','2025-08-20 15:38:25'),(11,26,134,167,'너이색히 쓰레기 색히','2025-08-22 11:48:00'),(13,4,176,42,'신고합니다','2025-08-27 10:40:38'),(14,33,174,177,'ㅁㄴㅇㅁㄴㅇㅁㄴㅇ','2025-08-27 11:11:18'),(15,35,191,184,'일 너무 많이 시킴;;','2025-09-04 16:24:28'),(16,4,42,176,'ㅎ','2025-09-04 16:32:54'),(17,4,42,91,'제주는 뮤슨','2025-09-04 16:45:38'),(18,4,42,91,'ㅋㅌㄹㅊ','2025-09-04 16:51:18'),(19,4,42,91,'SDFA','2025-09-08 14:35:34'),(20,35,181,194,'자꾸 남자를 공주로 만들려고 해요.... 살려주세요','2025-09-09 22:33:43'),(21,35,181,196,'TEST','2025-09-11 03:36:41'),(22,35,181,196,'하이','2025-09-11 09:59:33'),(23,22,125,185,'나이를 속입니다','2025-09-11 15:51:31'),(24,22,125,220,'술친자','2025-09-11 15:51:42'),(25,22,220,125,'권력 남용합니다','2025-09-11 15:52:22'),(26,22,125,185,'나이 또 속임','2025-09-11 16:07:50');
/*!40000 ALTER TABLE `report_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:25:04
