-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `global_free_comment_tb`
--

DROP TABLE IF EXISTS `global_free_comment_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `global_free_comment_tb` (
  `free_comment_id` int NOT NULL AUTO_INCREMENT,
  `free_id` int NOT NULL,
  `user_id` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`free_comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_free_comment_tb`
--

LOCK TABLES `global_free_comment_tb` WRITE;
/*!40000 ALTER TABLE `global_free_comment_tb` DISABLE KEYS */;
INSERT INTO `global_free_comment_tb` VALUES (1,1,28,'함께 뛰고 싶네요!','2025-07-24 06:41:49'),(2,2,21,'다음 글도 기대할게요 ?','2025-09-03 07:43:49'),(3,3,44,'러닝 의지가 생기네요 ?','2025-07-23 23:46:49'),(4,4,26,'함께 뛰고 싶네요!','2025-07-16 00:42:49'),(5,5,32,'오늘도 파이팅입니다 ?','2025-09-02 19:56:49'),(6,5,68,'함께 뛰고 싶네요!','2025-08-13 20:28:49'),(7,6,59,'공감합니다 ?','2025-08-18 09:28:49'),(8,7,37,'오늘도 파이팅입니다 ?','2025-08-08 12:41:49'),(9,8,36,'유용한 글 잘 보고 갑니다.','2025-09-01 23:47:49'),(10,8,49,'저도 같은 경험 있어요.','2025-09-09 05:44:49'),(11,8,42,'멋진 기록 축하해요 ?','2025-09-09 04:00:49'),(12,9,37,'함께 뛰고 싶네요!','2025-08-10 06:45:49'),(13,9,6,'멋진 기록 축하해요 ?','2025-07-22 10:06:49'),(14,9,10,'다음 글도 기대할게요 ?','2025-09-04 01:03:49'),(15,10,33,'러닝 의지가 생기네요 ?','2025-08-25 18:35:49'),(16,10,35,'공감합니다 ?','2025-09-04 18:53:49'),(17,10,55,'러닝 의지가 생기네요 ?','2025-07-26 10:28:49'),(18,11,30,'공감합니다 ?','2025-07-13 01:08:49'),(19,11,44,'공감합니다 ?','2025-08-02 16:59:49'),(20,12,9,'함께 뛰고 싶네요!','2025-08-31 03:59:49'),(21,12,49,'오늘도 파이팅입니다 ?','2025-08-28 08:25:49'),(22,12,8,'좋은 글 감사합니다 ?','2025-08-17 03:18:49'),(23,13,33,'러닝 의지가 생기네요 ?','2025-08-07 23:30:49'),(24,13,30,'함께 뛰고 싶네요!','2025-07-18 10:59:49'),(25,14,6,'오늘도 파이팅입니다 ?','2025-07-17 02:02:49'),(26,15,14,'저도 같은 경험 있어요.','2025-07-13 00:57:49');
/*!40000 ALTER TABLE `global_free_comment_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:25:02
