-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `gathering_tb`
--

DROP TABLE IF EXISTS `gathering_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gathering_tb` (
  `gathering_id` int NOT NULL AUTO_INCREMENT,
  `crew_id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `thumbnail_picture` text,
  `running_date` varchar(255) NOT NULL,
  `running_time` varchar(255) NOT NULL,
  `place_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `road_address` varchar(255) NOT NULL,
  `latitude` decimal(10,7) NOT NULL,
  `longitude` decimal(10,7) NOT NULL,
  `km` decimal(10,0) NOT NULL,
  `cost` int NOT NULL,
  `max_participants` int NOT NULL,
  `status` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`gathering_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gathering_tb`
--

LOCK TABLES `gathering_tb` WRITE;
/*!40000 ALTER TABLE `gathering_tb` DISABLE KEYS */;
INSERT INTO `gathering_tb` VALUES (1,22,58,'도심 속 러닝 ?','달리며 건강과 행복을 챙겨요.','https://hips.hearstapps.com/hmg-prod/images/gettyimages-1341854189-6540f8266a2ef.jpg','2025-09-22','19:30','당감동 산책로','부산광역시 진구 당감동','부산광역시 진구 당감동',35.1688000,129.0422000,10,7000,22,1,'2025-09-20 00:00:00'),(2,22,4,'도심 속 러닝 ?','부산의 시원한 바람과 함께 달려요!','https://www.transparentlabs.com/cdn/shop/articles/image1_1_985e1ff8-6709-4f15-a39f-28a5c282e780_1200x1200.jpg?v=1748023325','2025-09-07','21:15','양정동 체육공원','부산광역시 진구 양정동','부산광역시 진구 양정동',35.1681000,129.0710000,8,7000,17,1,'2025-09-04 00:00:00'),(3,22,58,'가을밤 러닝 모임 ?','달리며 건강과 행복을 챙겨요.','https://images.ctfassets.net/7ajcefednbt4/7emKH2B8NSKxgKyiRQG4sD/45a05b254dcf08b08b2bba3892df7649/Run_your_way_2024_25_Run_the_Boroughs_Paris.jpg?fm=webp&w=2560','2025-09-06','21:00','초읍 어린이대공원','부산광역시 진구 초읍동','부산광역시 진구 초읍동',35.1794000,129.0521000,6,6000,22,1,'2025-09-05 00:00:00'),(4,22,58,'친구랑 러닝하자 ?','편안하게 뛰는 크루런입니다.','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8eQBFwSXzWKVpDeDwJIMcYF8vcW84Xd8aoA&s','2025-09-08','21:15','전포동 카페거리','부산광역시 진구 전포동','부산광역시 진구 전포동',35.1579000,129.0643000,6,5000,19,1,'2025-09-05 00:00:00'),(5,22,58,'부산 러닝','새로운 코스를 함께 달려봐요.','https://img.youtube.com/vi/fE8d0g08KZ0/sddefault.jpg','2025-09-26','19:00','부전동 ○○공원','부산광역시 진구 부전동','부산광역시 진구 부전동',35.1629000,129.0595000,10,7000,17,1,'2025-09-24 00:00:00'),(6,22,4,'부산 야경 달리기 ✨','즐겁게 뛰고 가볍게 마무리합시다.','https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcQKDyrK_KfR5ecpsR3RhXgB9OLPBwdl0kgCVWscsY7AHzqsOiLV','2025-09-04','18:45','초읍 어린이대공원','부산광역시 진구 초읍동','부산광역시 진구 초읍동',35.1794000,129.0521000,9,5000,24,1,'2025-09-01 00:00:00'),(7,22,4,'조깅 런','페이스 상관없이 함께 뛰어요.','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRjc-sCdO5xMI6pW-T6D5B2RqqfdNE9nX8H9Iato6uCO45lXRke','2025-09-10','20:15','부전동 ○○공원','부산광역시 진구 부전동','부산광역시 진구 부전동',35.1629000,129.0595000,7,5000,16,1,'2025-09-09 00:00:00'),(8,22,54,'부산 야경 달리기 ✨','편안하게 뛰는 크루런입니다.','https://mblogthumb-phinf.pstatic.net/MjAyNTAyMDVfMjg3/MDAxNzM4NzUyOTk0ODE0.24Mu7IQZ0wqP3hAbymyw_p2170atTbPNQdsY_aTaGQIg.PQM1xpEKWYljI8-gY6Iob6bJMXGJX6tyG--s99pZH3gg.PNG/38.png?type=w800','2025-09-28','19:30','부전동 ○○공원','부산광역시 진구 부전동','부산광역시 진구 부전동',35.1629000,129.0595000,9,7000,21,1,'2025-09-24 00:00:00'),(9,22,4,'해운대 러닝','해운대 밤바다 달리실 분 모집','https://img1.daumcdn.net/thumb/C500x500/?fname=http://t1.daumcdn.net/brunch/service/user/9EoH/image/CFAT459eRavQTFNo_jp8s_reHXs.jpg','2025-09-12','21:00','해운대해수욕장','부산 해운대구 우동','',35.1585232,129.1598547,10,10000,10,1,'2025-09-11 10:36:23'),(10,22,54,'부산  밤거리','편안하게 뛰는 크루런입니다.','https://mblogthumb-phinf.pstatic.net/MjAxOTA5MDlfMjA2/MDAxNTY4MDAzMTAzMTI0.eQMcvUQeBg_b8KVKVOTG77sm7sWOmRIlN_cV_7nPh2kg.w2GfuZ59cR8g8Ea_ZKn0BUtov9EJB9osP0PaI3dH_fEg.JPEG.sarangkings/11.jpg?type=w800','2025-09-28','19:30','부전동 ○○공원','부산광역시 진구 부전동','부산광역시 진구 부전동',35.1629000,129.0595000,9,7000,21,1,'2025-09-24 00:00:00');
/*!40000 ALTER TABLE `gathering_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:24:59
