-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `global_notice_tb`
--

DROP TABLE IF EXISTS `global_notice_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `global_notice_tb` (
  `notice_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`notice_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_notice_tb`
--

LOCK TABLES `global_notice_tb` WRITE;
/*!40000 ALTER TABLE `global_notice_tb` DISABLE KEYS */;
INSERT INTO `global_notice_tb` VALUES (1,51,'zxvc','<p>qreqw</p><p><img src=\"http://localhost:8080/image/global/notice/c464a4db8cc84225ae8b1018ed934fb2_토스트.png\"></p><p>xzv</p>','2025-08-28 15:56:33'),(2,51,'zxvc','<p>qrwe</p><p><img src=\"http://localhost:8080/image/global/notice/9043eb4f2711493d98f91214bb7fe6d6_육비.png\"></p><p><br></p>','2025-08-28 15:57:07'),(3,51,'xzv','<p>qwr</p><p><img src=\"http://localhost:8080/image/global/notice/3c127d77e01b4975a15706fedbedfd85_육비.png\"></p><p><br></p>','2025-08-28 15:57:20'),(4,51,'zxcv','<p>qwrexzcv</p><p>vxczvcxzvxczvcxvzxczxcxzvczxc</p><p>zxczxczxczxczxcxzcxzczxcv</p><p>zxczxczxczxczxc</p><p><img src=\"http://localhost:8080/image/global/notice/78fdaa81b59a420895935ea6d57ef249_육비.png\"></p>','2025-08-28 15:57:59'),(5,50,'시스템 점검 안내','안녕하세요. 시스템 점검이 예정되어 있어 안내드립니다.','2025-08-05 12:10:07'),(6,52,'앱 업데이트 소식','앱 업데이트가 완료되었습니다. 최신 버전을 이용해주세요.','2025-09-02 06:54:07'),(7,4,'회원 혜택 확대','회원 혜택이 확대되어 더 많은 서비스를 이용할 수 있습니다.','2025-09-06 15:14:07'),(8,58,'보안 강화 정책 안내','보안 강화를 위해 비밀번호 정책이 변경됩니다.','2025-08-18 09:44:07'),(9,51,'추가 기능 안내','새로운 기능이 추가되었습니다. 자세한 내용은 공지사항을 참고해주세요.','2025-09-01 21:30:07'),(10,4,'이벤트 참여 방법','이벤트 참여 방법을 안내드립니다.','2025-08-22 16:50:07'),(11,50,'공지: 커뮤니티 정책','커뮤니티 정책이 일부 개정되어 공지드립니다.','2025-08-28 08:22:07'),(12,52,'서버 안정화 작업','서버 안정화 작업이 진행됩니다. 이용에 참고 부탁드립니다.','2025-09-04 10:11:07'),(13,58,'정기 점검 안내','정기 점검 일정이 확정되어 안내드립니다.','2025-09-05 13:18:07'),(14,51,'추석 연휴 운영 안내','추석 연휴 동안 운영시간이 단축됩니다.','2025-08-30 19:40:07'),(15,4,'서비스 개선 사항','서비스가 개선되었습니다. 더욱 편리하게 이용하세요.','2025-09-03 11:07:07'),(16,50,'신규 버전 출시 안내','신규 버전이 출시되었습니다. 지금 업데이트 해주세요.','2025-09-07 14:55:07');
/*!40000 ALTER TABLE `global_notice_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:24:58
