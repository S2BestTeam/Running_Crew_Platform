-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `crew_free_comment_tb`
--

DROP TABLE IF EXISTS `crew_free_comment_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crew_free_comment_tb` (
  `free_comment_id` int NOT NULL AUTO_INCREMENT,
  `free_id` int NOT NULL,
  `user_id` int NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`free_comment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crew_free_comment_tb`
--

LOCK TABLES `crew_free_comment_tb` WRITE;
/*!40000 ALTER TABLE `crew_free_comment_tb` DISABLE KEYS */;
INSERT INTO `crew_free_comment_tb` VALUES (47,85,68,'다음엔 하프 도전해봅시다!','2025-08-26 13:43:03'),(48,86,58,'뉴트리션 추천 부탁드립니다 ?','2025-09-07 17:19:51'),(49,86,58,'뉴트리션 추천 부탁드립니다 ?','2025-09-10 09:30:36'),(50,87,59,'오늘 코스 최고였어요 ?','2025-08-18 17:57:38'),(51,87,70,'뉴트리션 추천 부탁드립니다 ?','2025-09-16 07:49:10'),(52,88,73,'굿런! 다음주도 같이 뛰어요 ?‍♂️','2025-09-06 15:09:29'),(53,88,70,'굿런! 다음주도 같이 뛰어요 ?‍♂️','2025-08-07 17:13:41'),(54,89,60,'오늘 코스 최고였어요 ?','2025-09-04 17:09:04'),(55,90,60,'오늘 코스 최고였어요 ?','2025-08-28 16:52:56'),(56,91,72,'다음엔 하프 도전해봅시다!','2025-09-20 18:48:28'),(57,92,63,'주중에도 한 번 더 달려요!','2025-08-10 08:00:41'),(58,93,69,'에너지 넘쳤습니다 ?','2025-09-20 16:39:40'),(59,93,59,'페이스 유지 깔끔했습니다.','2025-08-18 08:04:47'),(60,93,59,'페이스 유지 깔끔했습니다.','2025-08-18 08:04:47'),(61,94,59,'오늘 코스 최고였어요 ?','2025-09-18 20:00:47'),(62,94,72,'사진 공유 부탁해요 ?','2025-09-17 13:20:02'),(63,95,70,'뉴트리션 추천 부탁드립니다 ?','2025-08-05 13:46:55'),(64,95,54,'다음엔 언덕 인터벌 가시죠!','2025-09-04 15:19:57'),(65,96,58,'페이스 유지 깔끔했습니다.','2025-09-27 21:39:35'),(66,96,70,'번개런 또 열어요!','2025-09-13 19:43:18'),(67,97,64,'다음엔 하프 도전해봅시다!','2025-09-22 10:44:02'),(68,98,61,'굿런! 다음주도 같이 뛰어요 ?‍♂️','2025-08-22 15:48:41'),(69,99,71,'굿런! 다음주도 같이 뛰어요 ?‍♂️','2025-08-15 16:31:29'),(70,99,14,'에너지 넘쳤습니다 ?','2025-08-17 19:09:58'),(71,100,67,'주중에도 한 번 더 달려요!','2025-09-28 22:23:01'),(72,101,65,'날씨가 딱 러닝각이었네요 ☀️','2025-08-01 19:43:53'),(73,101,60,'기록 갱신 축하해요 ?','2025-09-22 10:02:40'),(74,102,58,'페이스 유지 깔끔했습니다.','2025-08-26 12:50:42'),(75,102,69,'스트레칭 잊지말기 ?','2025-08-19 07:50:00'),(76,103,71,'수고 많았어요! 페이스 좋았습니다.','2025-09-15 19:31:54'),(77,103,54,'수고 많았어요! 페이스 좋았습니다.','2025-09-16 15:12:48'),(78,104,64,'다음엔 하프 도전해봅시다!','2025-08-23 13:37:20'),(79,105,73,'페이스 유지 깔끔했습니다.','2025-08-18 09:32:22'),(80,105,68,'주중에도 한 번 더 달려요!','2025-08-01 11:59:10'),(81,106,61,'오늘 코스 최고였어요 ?','2025-08-08 13:27:55'),(82,106,60,'다음엔 언덕 인터벌 가시죠!','2025-08-08 17:43:34'),(83,107,54,'다음엔 언덕 인터벌 가시죠!','2025-08-08 09:36:33'),(84,107,61,'컨디션 좋아보였어요. 화이팅!','2025-09-08 18:23:24'),(85,108,61,'수고 많았어요! 페이스 좋았습니다.','2025-08-17 09:53:21'),(86,109,14,'주중에도 한 번 더 달려요!','2025-09-24 10:36:36'),(87,110,63,'기록 갱신 축하해요 ?','2025-09-11 20:59:02'),(88,110,60,'페이스 유지 깔끔했습니다.','2025-09-22 13:08:06');
/*!40000 ALTER TABLE `crew_free_comment_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:24:59
