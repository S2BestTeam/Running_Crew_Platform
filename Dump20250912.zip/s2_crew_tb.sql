-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `crew_tb`
--

DROP TABLE IF EXISTS `crew_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `crew_tb` (
  `crew_id` int NOT NULL AUTO_INCREMENT,
  `gungu_id` int DEFAULT NULL,
  `profile_picture` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail_picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'default.jpg',
  `crew_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `limited_people` int DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `total_km` double DEFAULT '0',
  PRIMARY KEY (`crew_id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crew_tb`
--

LOCK TABLES `crew_tb` WRITE;
/*!40000 ALTER TABLE `crew_tb` DISABLE KEYS */;
INSERT INTO `crew_tb` VALUES (1,1,'https://anysports.net/admin/amboard/imgview.php?no=7494&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7494&group=basic&code=crew&mode=thumbs','한강러닝크루',5,'한강에서 함께 뛰어요!','<p><strong>한강러닝크루</strong>에 오신걸 환영해요!</p><ul><li>매주 토요일 오전 7시</li><li>초보자 대환영</li><li>런닝 후 브런치 모임</li></ul><p><em>한강의 시원한 바람과 함께 달려요!</em></p>',20,'2024-01-15 09:30:00',0),(2,3,'https://anysports.net/admin/amboard/imgview.php?no=7493&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7493&group=basic&code=crew&mode=thumbs','대구마라톤팀',7,'42.195km 완주가 목표!','<p>?‍♂️ <strong>풀마라톤 완주</strong>를 꿈꾸는 분들 모여주세요!</p><ul><li>체계적인 훈련 프로그램</li><li>경험 많은 리더의 코칭</li><li>함께라면 할 수 있어요!</li></ul>',25,'2024-01-20 14:15:00',0),(3,5,'https://anysports.net/admin/amboard/imgview.php?no=7492&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7492&group=basic&code=crew&mode=thumbs','무등산트레일러너스',9,'산악러닝의 매력에 빠져보세요','<p>?️ <strong>무등산 트레일 러닝</strong></p><p>자연과 함께하는 힐링 러닝을 경험해보세요!</p><ul><li>안전한 트레일 코스</li><li>초보자도 환영</li><li>하체근력 강화 효과</li></ul>',15,'2024-02-05 08:00:00',0),(4,7,'https://anysports.net/admin/amboard/imgview.php?no=7488&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7488&group=basic&code=crew&mode=thumbs','울산야간러닝',51,'밤하늘 아래서 달려요','<p>52러닝클럽은 \"일년 52주 중 52번,\"</p><p>\"1주일에 1번씩이라도 꾸준하게 뛰자\" 라는 모토를 가지고 만들어진 크루입니다.</p><p><br></p><p>매주 목요일 오후 8시30분에 정기모임을 진행하고 있으며, 다른 요일에도 뛰기를 희망하시는 분들은 자유롭게 번개러닝을 진행하고 있습니다.</p><p><br></p><p>(정기모임이 최우선입니다)</p><p><br></p><p>주요 활동 지역은 경포호수, 남대천, 종합경기장, 강릉원주대 후문 등 강릉일대에서 활동하고 있습니다.</p><p><br></p><p>★크루원 모집링크★</p><p>https://www.daangn.com/kr/groups/9ALvOy0mPPut_medium=copy_link</p><p><br></p><p>★크루원 모집 조건★</p><p>러닝을 시작하고 싶지만 용기가 없으셨던 분들, 같이 뛸 사람이 없어 망설이셨던 분들, 건강하고 꾸준하게 크루활동을 하고 싶은 마음만 있으시다면 모두 환영입니다. (실력불문, 나이불문, 성별불문, 국적불문) (페이스별로 그룹을 나누어서 뛰고 있습니다)</p>',50,'2024-02-20 19:00:00',0),(5,13,'https://api.dicebear.com/7.x/adventurer-neutral/png?seed=crew5&size=400','https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=800&q=80','안양천러닝클럽',17,'안양천을 따라 달려요','<p>?️ <strong>32km 안양천 러닝 코스</strong></p><p>평지 코스로 초보자도 안전하게 즐길 수 있어요!</p><ul><li>거리별 그룹 운영</li><li>화장실, 휴게소 완비</li><li>야간 조명 시설 완벽</li></ul>',30,'2024-03-10 07:30:00',0),(6,1,'https://anysports.net/admin/amboard/imgview.php?no=7485&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7485&group=basic&code=crew&mode=thumbs','광주러닝마스터즈',48,'러닝 마스터가 되어보세요','<p>? <strong>체계적이고 전문적인 러닝 훈련</strong></p><p>초급부터 고급까지 단계별 맞춤 훈련!</p><ul><li>개인별 맞춤 훈련계획</li><li>영양 및 부상예방 교육</li><li>정기 체력측정</li></ul><p><em>함께 성장하는 러닝 커뮤니티!</em></p>',22,'2024-03-25 06:00:00',0),(22,8,'https://anysports.net/admin/amboard/imgview.php?no=7481&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7481&group=basic&code=crew&mode=thumbs','공주들의 모임',58,'우아한 러닝을 즐기는 공주들의 모임','<p>? <strong>우아한 러닝을 즐기는 공주들의 모임</strong> ?</p><p>달리기를 단순한 운동이 아닌 <strong>작은 행복과 우아한 일상</strong>으로 즐기고 싶은 사람들이 모였습니다.</p><p>우리는 숫자나 기록에만 집착하지 않고, 각자의 페이스로 달리면서 하루의 스트레스를 내려놓아요.</p><p>함께 달리고, 함께 웃고, 때로는 달리기 끝나고 맛있는 브런치로 하루를 마무리하기도 해요.</p><p>서로를 챙기고 응원하는 분위기 속에서 달리기가 더 즐거워지고,</p><p>땀 흘리는 순간마저 하나의 추억으로 남는 곳 – 그게 바로 우리 크루예요.</p><p>?‍♀️ <strong>이런 분들에게 딱!</strong></p><ol><li data-list=\"bullet\"><span class=\"ql-ui\" contenteditable=\"false\"></span>러닝을 통해 건강과 일상을 관리하고 싶은 분</li><li data-list=\"bullet\"><span class=\"ql-ui\" contenteditable=\"false\"></span>기록보다는 즐거움, 교류, 힐링을 원하는 분</li><li data-list=\"bullet\"><span class=\"ql-ui\" contenteditable=\"false\"></span>소소한 일상 공유와 달리기 후 수다까지 좋아하는 분</li></ol><p>? 우리와 함께 달린다면 러닝은 더 이상 혼자 하는 운동이 아니라,</p><p><strong>함께 웃고 성장하는 작은 축제</strong>가 될 거예요.</p>',30,'2025-08-18 17:02:44',331),(32,8,'https://anysports.net/admin/amboard/imgview.php?no=7480&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7480&group=basic&code=crew&mode=thumbs','왕자들의 모임',54,'우아한 러닝을 즐기는 왕자들의 모임','<p>? <strong>우아한 러닝을 즐기는 왕자들의 모임</strong> ?</p><p>달리기를 단순한 운동이 아닌 <strong>작은 행복과 우아한 일상</strong>으로 즐기고 싶은 사람들이 모였습니다.</p><p>우리는 숫자나 기록에만 집착하지 않고, 각자의 페이스로 달리면서 하루의 스트레스를 내려놓아요.</p><p>함께 달리고, 함께 웃고, 때로는 달리기 끝나고 맛있는 브런치로 하루를 마무리하기도 해요.</p><p>서로를 챙기고 응원하는 분위기 속에서 달리기가 더 즐거워지고,</p><p>땀 흘리는 순간마저 하나의 추억으로 남는 곳 – 그게 바로 우리 크루예요.</p><p>?‍♀️ <strong>이런 분들에게 딱!</strong></p><ol><li data-list=\"bullet\"><span class=\"ql-ui\" contenteditable=\"false\"></span>러닝을 통해 건강과 일상을 관리하고 싶은 분</li><li data-list=\"bullet\"><span class=\"ql-ui\" contenteditable=\"false\"></span>기록보다는 즐거움, 교류, 힐링을 원하는 분</li><li data-list=\"bullet\"><span class=\"ql-ui\" contenteditable=\"false\"></span>소소한 일상 공유와 달리기 후 수다까지 좋아하는 분</li></ol><p>? 우리와 함께 달린다면 러닝은 더 이상 혼자 하는 운동이 아니라,</p><p><strong>함께 웃고 성장하는 작은 축제</strong>가 될 거예요.</p>',11,'2025-08-21 15:12:25',0),(36,9,'https://anysports.net/admin/amboard/imgview.php?no=7477&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7477&group=basic&code=crew&mode=thumbs','션',57,'가나다','<p>?‍♂️ <strong>풀마라톤 완주</strong>를 꿈꾸는 분들 모여주세요!</p><ul><li>체계적인 훈련 프로그램</li><li>경험 많은 리더의 코칭</li><li>함께라면 할 수 있어요!</li></ul>',4,'2025-09-07 15:29:46',0),(37,11,'https://anysports.net/admin/amboard/imgview.php?no=7501&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7501&group=basic&code=crew&mode=thumbs','52 Running Club',1,'활동중인 2030 러닝크루','52러닝클럽은 ‘일년 52주 중 52번, 1주일에 1번씩이라도 꾸준하게 뛰자’ 라는 모토로 만들어진 크루입니다. 매주 목요일 오후 8시30분 정기모임 진행, 주요 활동 지역: 강릉 일대',50,'2025-09-11 09:41:04',0),(38,12,'https://anysports.net/admin/amboard/imgview.php?no=7499&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7499&group=basic&code=crew&mode=thumbs','Run With Us',2,'안동 목달클럽(ATRC)','창원에서 활동중인 2030 러닝크루. 실력 상관없이 함께 뛰고자 하는 사람들이 모였습니다.',40,'2025-09-11 09:41:04',0),(39,13,'https://anysports.net/admin/amboard/imgview.php?no=7498&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7498&group=basic&code=crew&mode=thumbs','목달클럽(ATRC)',3,'제주러닝크루 이런크루(2RUNCREW)','안동 목달클럽 입니다.',25,'2025-09-11 09:41:04',0),(40,4,'https://anysports.net/admin/amboard/imgview.php?no=7497&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7497&group=basic&code=crew&mode=thumbs','창원러닝크루 뛰닝',4,'창원러닝크루 뛰닝','창원러닝크루 뛰닝입니다.',35,'2025-09-11 09:41:04',0),(41,15,'https://anysports.net/admin/amboard/imgview.php?no=7496&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7496&group=basic&code=crew&mode=thumbs','이런크루(2RUNCREW)',5,'제주러닝크루 이런크루(2RUNCREW)','제주시내권을 중심으로 달리는 신생 러닝크루입니다.',20,'2025-09-11 09:41:04',0),(42,6,'https://anysports.net/admin/amboard/imgview.php?no=7494&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7494&group=basic&code=crew&mode=thumbs','더뉴런(THE NEW RUN CLUB)',6,'THE NEW RUN CLUB , 더뉴런','서울·경기 수도권 러닝 클럽 더뉴런 입니다.',45,'2025-09-11 09:41:04',0),(43,7,'https://anysports.net/admin/amboard/imgview.php?no=7493&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7493&group=basic&code=crew&mode=thumbs','연어런크루 SRC',7,'연어런클럽 SRC','매주 화·목 정기런, 양양을 배경으로 달립니다.',30,'2025-09-11 09:41:04',0),(44,8,'https://anysports.net/admin/amboard/imgview.php?no=7492&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7492&group=basic&code=crew&mode=thumbs','와우러닝크루(W.A.A.W)',8,'제주러닝크루 W.A.A.W(와우러닝크루)','함께하는 즐거움을 추구하는 러닝 크루.',28,'2025-09-11 09:41:04',0),(45,9,'https://anysports.net/admin/amboard/imgview.php?no=7491&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7491&group=basic&code=crew&mode=thumbs','대전러닝크루 GMW',9,'Going My Way, GMW 러닝크루','대전에서 활동하는 러닝 크루 GMW 입니다.',36,'2025-09-11 09:41:04',0),(46,10,'https://anysports.net/admin/amboard/imgview.php?no=7490&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7490&group=basic&code=crew&mode=thumbs','대전러닝크루 042DRC',10,'대전러닝크루 042DRC','정기런 매주 목요일 20시, 일요일 19시에 진행.',33,'2025-09-11 09:41:04',0),(47,11,'https://anysports.net/admin/amboard/imgview.php?no=7488&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7488&group=basic&code=crew&mode=thumbs','장수러닝크루',11,'전라북도 장수군의 장수러닝크루','매주 화요일 저녁 한누리전당에서 정기런 진행.',22,'2025-09-11 09:41:04',0),(48,12,'https://anysports.net/admin/amboard/imgview.php?no=7487&group=basic&code=crew&mode=thumbs','https://anysports.net/admin/amboard/imgview.php?no=7487&group=basic&code=crew&mode=thumbs','강원연합러닝크루 뛰드래요',12,'강원연합러닝크루 \'뛰드래요\'','강원 지역 청년들이 함께 달리는 러닝 크루.',27,'2025-09-11 09:41:04',0);
/*!40000 ALTER TABLE `crew_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:25:01
