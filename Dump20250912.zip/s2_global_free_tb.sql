-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `global_free_tb`
--

DROP TABLE IF EXISTS `global_free_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `global_free_tb` (
  `free_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`free_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global_free_tb`
--

LOCK TABLES `global_free_tb` WRITE;
/*!40000 ALTER TABLE `global_free_tb` DISABLE KEYS */;
INSERT INTO `global_free_tb` VALUES (1,51,'오늘도 즐거운 하루 ?','마라톤 다녀왔는데 정말 좋은 경험이었어요.','2025-07-27 22:20:57'),(2,29,'주말 계획 있으신가요?','러닝은 즐겁게 하는 게 최고죠!','2025-08-08 19:30:57'),(3,64,'아침 조깅 다녀왔습니다','날씨가 너무 좋아서 뛰기 딱이네요.','2025-08-22 18:40:57'),(4,8,'날씨가 너무 좋네요 ?','같이 달릴 러닝메이트 구합니다.','2025-07-26 05:47:57'),(5,23,'기록 갱신 성공!','아침에 뛰고 하루를 시작하니 상쾌합니다.','2025-08-13 23:01:57'),(6,43,'즐겁게 달립시다!','첫 러닝이라 설레네요.','2025-07-04 13:28:57'),(7,14,'슬럼프 극복하는 법?','날씨가 너무 좋아서 뛰기 딱이네요.','2025-09-09 22:12:57'),(8,15,'새로운 신발 샀어요 ?','부상 조심하시고 스트레칭 꼭 하세요.','2025-08-15 01:53:57'),(9,29,'마라톤 후기 공유합니다','저는 이런 루틴으로 훈련하고 있습니다.','2025-08-17 11:17:57'),(10,55,'오늘도 즐거운 하루 ?','같이 달릴 러닝메이트 구합니다.','2025-06-15 19:22:57'),(11,28,'마라톤 후기 공유합니다','러닝하면서 알게 된 팁을 공유해요.','2025-08-18 11:48:57'),(12,33,'도전의식이 생기네요','부상 조심하시고 스트레칭 꼭 하세요.','2025-07-05 05:07:57'),(13,57,'슬럼프 극복하는 법?','새로운 목표를 세우니 동기부여가 됩니다.','2025-08-29 13:36:57'),(14,50,'부상 예방 스트레칭법','아침에 뛰고 하루를 시작하니 상쾌합니다.','2025-07-03 11:15:57'),(15,52,'첫 러닝 인증 ?','<p>날씨가 너무 좋아서 뛰기 딱이네요.</p><p><img src=\"https://i.namu.wiki/i/qPPdkzJbwej_5R3eFlBt11Kg8m0xzWw9A9phftaE9e_94CqL1bDIkgBY8Qg2uJ76S67fJXlBk4MHHb6zEj0Ypg.webp\"></p><p><br></p>','2025-07-05 05:46:57');
/*!40000 ALTER TABLE `global_free_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:25:00
