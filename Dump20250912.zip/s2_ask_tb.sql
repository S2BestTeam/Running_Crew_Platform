-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: mysql.c9uqg6qy20bd.ap-northeast-2.rds.amazonaws.com    Database: s2
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `ask_tb`
--

DROP TABLE IF EXISTS `ask_tb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ask_tb` (
  `ask_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_answer` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`ask_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ask_tb`
--

LOCK TABLES `ask_tb` WRITE;
/*!40000 ALTER TABLE `ask_tb` DISABLE KEYS */;
INSERT INTO `ask_tb` VALUES (1,51,'ㅋㅌㅍ','<p>ㅁㄴㄹㅇㅋㅌㅊㅍ</p><p><img src=\"http://localhost:8080/image/ask/21335d06a6494e3e97f3f44c42d51391_육비.png\"></p><p><br></p>','2025-08-29 12:48:49',1),(2,51,'ㅌㅋㅊㅍ','<p>ㅁㄴㄾㅊㅋㅍ</p><p><img src=\"http://localhost:8080/image/ask/d4bf3cd19acf4aacb49bc9d3ae941d5e_기유.jpg\"></p><p>ㅌㅋㅍ</p>','2025-08-29 15:18:36',1),(3,51,'ㅋㅌㅍㅊ','<p>ㅋㅌㅍㅊㅋㅌㅍㅊ</p>','2025-08-29 15:18:55',1),(4,52,'xzvc','<p>weqcsda</p>','2025-08-29 15:29:00',1),(5,4,'관리자 맘에 안드는데요 ','<p>닉네임 자꾸 맘대로 바꾸고 나이로 신고 하고 </p><p>관리자 진짜 맘에 안드네요 </p><p>관리자 교체해주세요 </p>','2025-09-01 16:31:55',1);
/*!40000 ALTER TABLE `ask_tb` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-09-12  9:25:03
